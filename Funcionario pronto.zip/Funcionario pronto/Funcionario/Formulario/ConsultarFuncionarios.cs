﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Funcionario.Models;
using Funcionario.Formulario;
using Funcionario.Contexto;

namespace Funcionario.Formulario
{
    public partial class ConsultarFuncionarios : Form
    {
        List<Funcionarios> ListaFuncionarios = new List<Funcionarios>();
        public ConsultarFuncionarios()
        {
            InitializeComponent();

            ListaFuncionarios = Context.ListaFuncionarios.ToList();
            var funcSelec = ListaFuncionarios.Where(m => m.CPF != null).ToList();
            dtFuncionario.DataSource = funcSelec.OrderBy(m => m.Nome).ToList();
        }

      


    }
}
