﻿namespace Funcionario.Formulario
{
    partial class CadastrarFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            txtNome = new TextBox();
            txtFuncao = new TextBox();
            txtCep = new TextBox();
            txtRg = new TextBox();
            txtSala = new TextBox();
            txtMunicipio = new TextBox();
            txtBairro = new TextBox();
            txtEndereco = new TextBox();
            txtTelefone = new TextBox();
            txtCtps = new TextBox();
            txtCpf = new TextBox();
            txtSetor = new TextBox();
            btSalvar = new Button();
            btCancelar = new Button();
            cbEstados = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(10, 8);
            label1.Name = "label1";
            label1.Size = new Size(840, 23);
            label1.TabIndex = 0;
            label1.Text = "Cadastrar Funcionario";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(10, 79);
            label2.Name = "label2";
            label2.Size = new Size(49, 17);
            label2.TabIndex = 1;
            label2.Text = "Nome:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(10, 166);
            label3.Name = "label3";
            label3.Size = new Size(56, 17);
            label3.TabIndex = 2;
            label3.Text = "Função:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(210, 166);
            label4.Name = "label4";
            label4.Size = new Size(37, 17);
            label4.TabIndex = 3;
            label4.Text = "Sala:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(210, 244);
            label5.Name = "label5";
            label5.Size = new Size(74, 17);
            label5.TabIndex = 4;
            label5.Text = "Municipio:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(210, 79);
            label6.Name = "label6";
            label6.Size = new Size(29, 17);
            label6.TabIndex = 5;
            label6.Text = "RG:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(411, 79);
            label7.Name = "label7";
            label7.Size = new Size(35, 17);
            label7.TabIndex = 6;
            label7.Text = "CPF:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(575, 166);
            label8.Name = "label8";
            label8.Size = new Size(65, 17);
            label8.TabIndex = 7;
            label8.Text = "Telefone:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(575, 79);
            label9.Name = "label9";
            label9.Size = new Size(43, 17);
            label9.TabIndex = 8;
            label9.Text = "CTPS:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(411, 166);
            label10.Name = "label10";
            label10.Size = new Size(45, 17);
            label10.TabIndex = 9;
            label10.Text = "Setor:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(10, 244);
            label11.Name = "label11";
            label11.Size = new Size(83, 17);
            label11.TabIndex = 10;
            label11.Text = "Estado (UF):";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(408, 244);
            label12.Name = "label12";
            label12.Size = new Size(49, 17);
            label12.TabIndex = 11;
            label12.Text = "Bairro:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(575, 244);
            label13.Name = "label13";
            label13.Size = new Size(68, 17);
            label13.TabIndex = 12;
            label13.Text = "Endereço:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(10, 315);
            label14.Name = "label14";
            label14.Size = new Size(35, 17);
            label14.TabIndex = 13;
            label14.Text = "Cep:";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNome.Location = new Point(10, 96);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(145, 25);
            txtNome.TabIndex = 14;
            // 
            // txtFuncao
            // 
            txtFuncao.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtFuncao.Location = new Point(10, 183);
            txtFuncao.Name = "txtFuncao";
            txtFuncao.Size = new Size(145, 25);
            txtFuncao.TabIndex = 15;
            // 
            // txtCep
            // 
            txtCep.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCep.Location = new Point(10, 332);
            txtCep.Name = "txtCep";
            txtCep.Size = new Size(145, 25);
            txtCep.TabIndex = 17;
            // 
            // txtRg
            // 
            txtRg.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtRg.Location = new Point(210, 96);
            txtRg.Name = "txtRg";
            txtRg.Size = new Size(145, 25);
            txtRg.TabIndex = 18;
            // 
            // txtSala
            // 
            txtSala.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSala.Location = new Point(210, 183);
            txtSala.Name = "txtSala";
            txtSala.Size = new Size(145, 25);
            txtSala.TabIndex = 19;
            // 
            // txtMunicipio
            // 
            txtMunicipio.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMunicipio.Location = new Point(210, 261);
            txtMunicipio.Name = "txtMunicipio";
            txtMunicipio.Size = new Size(145, 25);
            txtMunicipio.TabIndex = 20;
            // 
            // txtBairro
            // 
            txtBairro.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBairro.Location = new Point(408, 261);
            txtBairro.Name = "txtBairro";
            txtBairro.Size = new Size(145, 25);
            txtBairro.TabIndex = 21;
            // 
            // txtEndereco
            // 
            txtEndereco.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEndereco.Location = new Point(575, 261);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(145, 25);
            txtEndereco.TabIndex = 22;
            // 
            // txtTelefone
            // 
            txtTelefone.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTelefone.Location = new Point(575, 183);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(145, 25);
            txtTelefone.TabIndex = 23;
            // 
            // txtCtps
            // 
            txtCtps.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCtps.Location = new Point(575, 96);
            txtCtps.Name = "txtCtps";
            txtCtps.Size = new Size(145, 25);
            txtCtps.TabIndex = 24;
            // 
            // txtCpf
            // 
            txtCpf.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCpf.Location = new Point(411, 96);
            txtCpf.Name = "txtCpf";
            txtCpf.Size = new Size(145, 25);
            txtCpf.TabIndex = 25;
            // 
            // txtSetor
            // 
            txtSetor.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSetor.Location = new Point(411, 183);
            txtSetor.Name = "txtSetor";
            txtSetor.Size = new Size(145, 25);
            txtSetor.TabIndex = 26;
            // 
            // btSalvar
            // 
            btSalvar.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btSalvar.Location = new Point(210, 323);
            btSalvar.Name = "btSalvar";
            btSalvar.Size = new Size(146, 39);
            btSalvar.TabIndex = 27;
            btSalvar.Text = "Salvar";
            btSalvar.UseVisualStyleBackColor = true;
            btSalvar.Click += btSalvar_Click;
            // 
            // btCancelar
            // 
            btCancelar.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCancelar.Location = new Point(407, 323);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(146, 39);
            btCancelar.TabIndex = 28;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = true;
            btCancelar.Click += btCancelar_Click;
            // 
            // cbEstados
            // 
            cbEstados.FormattingEnabled = true;
            cbEstados.Location = new Point(10, 261);
            cbEstados.Name = "cbEstados";
            cbEstados.Size = new Size(145, 21);
            cbEstados.TabIndex = 29;
            cbEstados.SelectedIndexChanged += cbEstados_SelectedIndexChanged;
            // 
            // CadastrarFuncionario
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(862, 381);
            Controls.Add(cbEstados);
            Controls.Add(btCancelar);
            Controls.Add(btSalvar);
            Controls.Add(txtSetor);
            Controls.Add(txtCpf);
            Controls.Add(txtCtps);
            Controls.Add(txtTelefone);
            Controls.Add(txtEndereco);
            Controls.Add(txtBairro);
            Controls.Add(txtMunicipio);
            Controls.Add(txtSala);
            Controls.Add(txtRg);
            Controls.Add(txtCep);
            Controls.Add(txtFuncao);
            Controls.Add(txtNome);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Microsoft Sans Serif", 8.25F);
            Name = "CadastrarFuncionario";
            Text = "CadastrarFuncionario";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private TextBox txtNome;
        private TextBox txtFuncao;
        private TextBox txtCep;
        private TextBox txtRg;
        private TextBox txtSala;
        private TextBox txtMunicipio;
        private TextBox txtBairro;
        private TextBox txtEndereco;
        private TextBox txtTelefone;
        private TextBox txtCtps;
        private TextBox txtCpf;
        private TextBox txtSetor;
        private Button btSalvar;
        private Button btCancelar;
        private ComboBox cbEstados;
    }
}