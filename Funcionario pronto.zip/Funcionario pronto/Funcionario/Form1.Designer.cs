﻿namespace Funcionario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btCadastrarFuncionario = new Button();
            btConsultarFuncionario = new Button();
            SuspendLayout();
            // 
            // btCadastrarFuncionario
            // 
            btCadastrarFuncionario.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCadastrarFuncionario.Location = new Point(39, 39);
            btCadastrarFuncionario.Name = "btCadastrarFuncionario";
            btCadastrarFuncionario.Size = new Size(280, 120);
            btCadastrarFuncionario.TabIndex = 0;
            btCadastrarFuncionario.Text = "Cadastrar Funcionario";
            btCadastrarFuncionario.UseVisualStyleBackColor = true;
            btCadastrarFuncionario.Click += btCadastrarFuncionario_Click;
            // 
            // btConsultarFuncionario
            // 
            btConsultarFuncionario.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btConsultarFuncionario.Location = new Point(385, 39);
            btConsultarFuncionario.Name = "btConsultarFuncionario";
            btConsultarFuncionario.Size = new Size(280, 120);
            btConsultarFuncionario.TabIndex = 1;
            btConsultarFuncionario.Text = "Consultar Funcionario";
            btConsultarFuncionario.UseVisualStyleBackColor = true;
            btConsultarFuncionario.Click += btConsultarFuncionario_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btConsultarFuncionario);
            Controls.Add(btCadastrarFuncionario);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btCadastrarFuncionario;
        private Button btConsultarFuncionario;
    }
}
