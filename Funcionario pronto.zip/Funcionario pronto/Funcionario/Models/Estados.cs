﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Funcionario.Contexto;

namespace Funcionario.Models
{
    public class Estado
    {

        public static List<string> Lista = new List<string>
            {
                "",
                "Acre",
                "Alagoas",
                "Amapá",
                "Amazonas",
                "Bahia",
                "Ceará",
                "Distrito Federal",
                "Espírito Santo",
                "Goiás",
                "Maranhão",
                "Mato Grosso",
                "Mato Grosso do Sul",
                "Minas Gerais",
                "Pará",
                "Paraíba",
                "Paraná",
                "Pernambuco",
                "Piauí",
                "Rio de Janeiro",
                "Rio Grande do Norte",
                "Rio Grande do Sul",
                "Rondônia",
                "Roraima",
                "Santa Catarina",
                "São Paulo",
                "Sergipe",
                "Tocantins"
            };
        //public int Id { get; set; }

        //public string Nome { get; set; }

        //public int id = 1;


        //public void NomeEstado()
        //{

        //    Estados Nomes = new Estados();

        //    Nomes.Id = id;
        //    Nomes.Nome = "Rondônia";

        //    Context.ListaEstados.Add(Nomes);
        //    id++;

        //    Estados Nomes2 = new Estados();
        //    Nomes2.Id = id;
        //    Nomes2.Nome = "Acre";
        //    Context.ListaEstados.Add(Nomes2);
        //    id++;

        //    Estados Nomes3 = new Estados();
        //    Nomes3.Id = id;
        //    Nomes3.Nome = "São Paulo";
        //    Context.ListaEstados.Add(Nomes3);
        //    id++;

        //}
    }


}
