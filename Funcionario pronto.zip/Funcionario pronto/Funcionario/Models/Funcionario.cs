﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionario.Models
{
    public class Funcionarios
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string RG { get; set; }
        public string CPF { get; set; }
        public string CTPS { get; set; }
        public string funcao { get; set; }
        public string setor { get; set; }
        public string sala { get; set; }
        public string Telefone { get; set; }
        public string Estado { get; set; }
        public string Cidade { get; set; }
        public string Bairro { get; set; }
        public int Endereco { get; set; }
        public string Cep { get; set; }

        public bool ValidarCpf(string CPF)
        {
            if (string.IsNullOrWhiteSpace(CPF))
                return false;

            int[] digitos = new int[11];
            int pos = 0;

            for (int i = 0; i < CPF.Length && pos < 11; i++)
            {
                char c = CPF[i];
                if (c >= '0' && c <= '9')
                {
                    digitos[pos++] = c - '0';
                }
            }

            if (pos != 11)
                return false;

            bool todosIguais = true;
            for (int i = 1; i < digitos.Length; i++)
            {
                if (digitos[i] != digitos[0])
                {
                    todosIguais = false;
                    break;
                }
            }
            if (todosIguais)
                return false;

            int soma = 0;
            for (int i = 0; i < 9; i++)
            {
                soma += digitos[i] * (10 - i);
            }
            int resto = soma % 11;
            int digito1 = resto < 2 ? 0 : 11 - resto;

            if (digitos[9] != digito1)
                return false;

            soma = 0;
            for (int i = 0; i < 10; i++)
            {
                soma += digitos[i] * (11 - i);
            }
            resto = soma % 11;
            int digito2 = resto < 2 ? 0 : 11 - resto;

            return digitos[10] == digito2;

        }
       public bool CampoObrigatorio(Funcionarios funcionarios)
        {
            if (string.IsNullOrWhiteSpace(funcionarios.Nome))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.RG))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.CPF))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.CTPS))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.funcao))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.setor))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.sala))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.Telefone))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.Estado))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.Bairro))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (funcionarios.Endereco <= 0)
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(funcionarios.Cep))
            {
                MessageBox.Show("O campo Nome é obrigatório!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}
