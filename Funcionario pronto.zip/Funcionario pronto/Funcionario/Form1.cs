using Funcionario.Formulario;

namespace Funcionario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCadastrarFuncionario_Click(object sender, EventArgs e)
        {
            CadastrarFuncionario form = new CadastrarFuncionario();
            form.ShowDialog();
        }

        private void btConsultarFuncionario_Click(object sender, EventArgs e)
        {
            ConsultarFuncionarios form = new ConsultarFuncionarios();
            form.ShowDialog();
        }
    }
}
