﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Funcionario.Models;

namespace Funcionario.Contexto
{
    public static class Context
    {
        public static List<Funcionarios> ListaFuncionarios = new List<Funcionarios>();
        //public static List<Estados> ListaEstados = new List<Estados>();

    }
}
