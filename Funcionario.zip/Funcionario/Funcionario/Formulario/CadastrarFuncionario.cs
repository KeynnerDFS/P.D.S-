﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Funcionario.Models;
using Funcionario.Formulario;
using Funcionario.Contexto;

namespace Funcionario.Formulario
{
    public partial class CadastrarFuncionario : Form
    {
        public static int id = 1;
        public CadastrarFuncionario()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Funcionarios bagaço = new Funcionarios();
            bagaço.Nome = txtNome.Text;
            bagaço.CPF = txtCpf.Text;
            bagaço.CTPS = txtCtps.Text;
            bagaço.RG = txtRg.Text;
            bagaço.funcao = txtFuncao.Text;
            bagaço.setor = txtSetor.Text;
            bagaço.sala = txtSala.Text;
            bagaço.Telefone = txtTelefone.Text;
            bagaço.Estado = txtEstado.Text;
            bagaço.Cidade = txtMunicipio.Text;
            bagaço.Endereco = Convert.ToInt32(txtEndereco.Text);
            bagaço.Cep = txtCep.Text;
            id++;
            Context.ListaFuncionarios.Add(bagaço);
            MessageBox.Show("SALVO COM SUCESSO!", "3A/INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtNome.Clear(); txtCpf.Clear(); txtCtps.Clear(); txtRg.Clear(); txtFuncao.Clear(); txtSetor.Clear(); txtSala.Clear(); txtTelefone.Clear(); txtEstado.Clear();
            txtMunicipio.Clear(); txtEndereco.Clear(); txtCep.Clear(); //fazer um combo box com os estados e cidades disponiveis para selecionar.
            txtNome.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtCpf.Clear(); txtCtps.Clear(); txtRg.Clear(); txtFuncao.Clear(); txtSetor.Clear(); txtSala.Clear(); txtTelefone.Clear(); txtEstado.Clear();
            txtMunicipio.Clear(); txtEndereco.Clear(); txtCep.Clear(); //fazer um combo box com os estados e cidades disponiveis para selecionar.
            txtNome.Select();
        }
    }
}
 